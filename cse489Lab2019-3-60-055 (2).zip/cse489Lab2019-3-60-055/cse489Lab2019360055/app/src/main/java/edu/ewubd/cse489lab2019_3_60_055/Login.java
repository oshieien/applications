package edu.ewubd.cse489lab2019_3_60_055;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {

    private EditText et_uid, et_pass;
    private CheckBox cb_remember_uid, cb_remember_pass;
    private Button bt_go, bt_signup, bt_exit,bt_Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_uid = findViewById(R.id.etuserId);
        et_pass = findViewById(R.id.etPassword);
        cb_remember_uid = findViewById(R.id.checkButton1);
        cb_remember_pass = findViewById(R.id.checkButton2);

        bt_Login = findViewById(R.id.etSignUp);
        bt_go = findViewById(R.id.etGo);
        bt_exit = findViewById(R.id.etExit);



        bt_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        bt_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, Signup.class);
                startActivity(intent);
                finish();
            }
        });

        bt_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processLogin();
            }
        });

    }


    private void processLogin() {

        String uid = et_uid.getText().toString().trim();
        String pass = et_pass.getText().toString().trim();
        String errorMsg = "";

        SharedPreferences sp = this.getSharedPreferences("user_input", MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();

        e.putBoolean("REM_UID", cb_remember_uid.isChecked());
        e.putBoolean("REM_PASS", cb_remember_pass.isChecked());
        e.commit();

        String sp_uid = sp.getString("USER_UID", "");
        String sp_pass = sp.getString("USER_PASS", "");

        if (uid.equals(sp_uid) && pass.equals(sp_pass) && !uid.isEmpty() && !pass.isEmpty()) {
            Intent intent = new Intent(Login.this, MainActivity.class);
            startActivity(intent);
            finish();
        }

        else {

            if (uid.length() < 4 || uid.length() > 6)
                errorMsg += "Invalid User ID \n";
            else if (!uid.equals(sp_uid))
                errorMsg += "User ID not found \n";

            if (pass.length() != 4)
                errorMsg += "Invalid Password \n";
            else if (!pass.equals(sp_pass))
                errorMsg += "Password did not matched \n";

            showErrorDialog(errorMsg);
        }

    }

    private void showErrorDialog(String errorMsg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(errorMsg);
        builder.setTitle("Error");
        builder.setCancelable(true);
        builder.setPositiveButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }
}