package edu.ewubd.cse489lab2019_3_60_055;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class lectureList extends AppCompatActivity {
    private ArrayList<ClassSummary> Lectures;
    private ListView lvlist;
    private TextView TvTittle;
    private ClassSummaryAdapter csAdapter;
    private Button btnBack,btnNew;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lecture_list);
        btnBack = findViewById(R.id.btnBack);
        btnNew = findViewById(R.id.btnNew);
        lvlist = findViewById(R.id.Lvlist);
        TvTittle = findViewById(R.id.TvTittle);
        Intent i = getIntent();
        if(i.hasExtra("courseName")){
            String title = i.getStringExtra("courseName");
            TvTittle.setText(title);
        }
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {finish();

            }
        });

        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent i = new Intent(lectureList.this,ClassSummaryActivity.class);
            i.putExtra("courseName", TvTittle.getText().toString());
            startActivity(i);

            }

        });
        Lectures=new ArrayList<>();
        csAdapter=new ClassSummaryAdapter(this,Lectures);
        lvlist.setAdapter(csAdapter);
        loadClassSummary();



    }

    @Override
    protected void onRestart() {
        super.onRestart();
        loadClassSummary();
    }

    private void loadClassSummary() {
        String q = "SELECT * FROM lectures WHERE course='"+TvTittle.getText().toString()+"';";
        ClassSummaryDB db = new ClassSummaryDB(this);
        Cursor cur = db.selectLectures(q);
        Lectures.clear();
        if (cur != null && cur.getCount() > 0) {
            while (cur.moveToNext()) {
                String id = cur.getString(0);
                String course = cur.getString(1);
                String type = cur.getString(2);
                long date = cur.getLong(3);
                String lecture = cur.getString(4);
                String topic = cur.getString(5);
                String summary = cur.getString(6);

                ClassSummary cs = new ClassSummary(id, course, type, date, lecture, topic, summary);
                Lectures.add(cs);
            }

            csAdapter.notifyDataSetInvalidated();
            csAdapter.notifyDataSetChanged();
        }
    }

}
